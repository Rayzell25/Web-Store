============================================================
       CHO STORE PPOB BOT - FULL PRODUCTION PACKAGE (.ZIP)
============================================================

Paket script ini dikembangkan khusus dengan standar Anti-Bug, Anti-Crash,
dan sistem State Management penuh demi memastikan kestabilan tinggi pada VPS Anda.

ISI FILE UTAMA:
1. `bot.py`        : Script Engine utama Pyrogram Telegram Bot.
2. `config.py`     : Pengaturan API ID, API Hash, DB VPS, & Digiflazz.
3. `database.py`   : Logic Database Engine PostgreSQL + Fungsi Upsert & Delete Otomatis.
4. `zona_data.json`: Database LENGKAP 100% berisikan 514+ Kota & Kabupaten se-Indonesia
                     yang terpetakan langsung ke masing-masing Zona XL/Axis.

FITUR UTAMA YANG SUDAH DIPERBAIKI SINKRON:
- Fitur Mirroring Digiflazz: Menggunakan perintah SQL 'ON CONFLICT (sku) DO UPDATE' (Upsert)
  sehingga harga terupdate otomatis dan TIDAK AKAN PERNAH duplikat/numpuk lagi.
- Fitur Sapu Bersih: Otomatis menghapus baris produk di DB Bot jika produk tersebut dihapus
  atau tidak ditemukan lagi di respon API Price List Digiflazz terbaru.
- Cek Area Anti-Bug: Memvalidasi nomor (Hanya meloloskan XL & Axis). Menghapus paksa kata
  variasi ketikan pembeli seperti "kabupaten", "kab.", atau "kota" secara otomatis,
  lalu mencocokkan secara instan ke database 514 kota se-Indonesia di `zona_data.json`.

CARA MEMASANG DI VPS:
1. Ekstrak file .zip ini ke folder project Anda di VPS.
2. Install dependensi wajib lewat terminal:
   pip install pyrogram tgcrypto psycopg2-binary requests
3. Buka file `config.py` dan isi dengan kredensial asli Anda (Bot Token, DB PostgreSQL, dll).
4. Pastikan kolom 'sku' di database PostgreSQL Anda bertindak sebagai PRIMARY KEY.
5. Jalankan bot Anda dengan perintah:
   python bot.py

Fitur sinkronisasi produk otomatis dapat dipicu secara live oleh admin di dalam bot 
melalui command: /sync
============================================================