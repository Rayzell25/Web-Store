import psycopg2
import requests
import hashlib
from config import *

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT
    )

def init_db():
    """Membuat tabel yang diperlukan secara otomatis saat bot dinyalakan"""
    conn = get_db_connection()
    cursor = conn.cursor()
    # Membuat tabel produk dengan primary key SKU agar fitur ON CONFLICT (Upsert) bekerja sempurna
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tabel_produk (
            sku VARCHAR(50) PRIMARY KEY,
            nama_produk VARCHAR(255) NOT NULL,
            harga INT NOT NULL,
            kategori VARCHAR(100),
            brand VARCHAR(100),
            status VARCHAR(50)
        );
    """)
    conn.commit()
    cursor.close()
    conn.close()
    print("Database Initialization Selesai.")

def sinkronisasi_produk_digiflazz():
    """
    Fungsi Sempurna (Anti-Bug & Mirroring 100%)
    - Mengupdate harga produk jika sudah ada.
    - Menambahkan produk baru jika belum ada.
    - Menghapus otomatis produk di bot jika sudah dihapus di panel Digiflazz.
    """
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1. Hitung Sign untuk API Digiflazz (MD5: username + apikey + "pricelist")
        sign_src = f"{DIGIFLAZZ_USERNAME}{DIGIFLAZZ_API_KEY}pricelist"
        sign = hashlib.md5(sign_src.encode('utf-8')).hexdigest()

        payload = {
            "cmd": "prepaid",
            "username": DIGIFLAZZ_USERNAME,
            "sign": sign
        }

        print("Menghubungi API Digiflazz untuk sinkronisasi...")
        response = requests.post("https://api.digiflazz.com/v1/price-list", json=payload)
        
        if response.status_code != 200:
            print(f"Gagal mengambil data Digiflazz. HTTP Status: {response.status_code}")
            return False

        res_json = response.json()
        if 'data' not in res_json:
            print(f"Respon API Digiflazz tidak valid: {res_json}")
            return False

        data_digi = res_json['data']
        sku_aktif_di_digi = []

        # 2. Proses Upsert (Insert Baru / Update yang Lama)
        for produk in data_digi:
            sku = produk.get('buyer_sku_code')
            nama = produk.get('product_name')
            harga = produk.get('price')
            kategori = produk.get('category')
            brand = produk.get('brand')
            
            # Cek keaktifan dari panel digiflazz
            buyer_product_status = produk.get('buyer_product_status', True)
            seller_product_status = produk.get('seller_product_status', True)
            
            # Hanya sinkronkan produk yang aktif di panel
            if buyer_product_status and seller_product_status:
                sku_aktif_di_digi.append(sku)

                cursor.execute("""
                    INSERT INTO tabel_produk (sku, nama_produk, harga, kategori, brand, status)
                    VALUES (%s, %s, %s, %s, %s, 'aktif')
                    ON CONFLICT (sku) DO UPDATE SET
                        nama_produk = EXCLUDED.nama_produk,
                        harga = EXCLUDED.harga,
                        kategori = EXCLUDED.kategori,
                        brand = EXCLUDED.brand,
                        status = 'aktif';
                """, (sku, nama, harga, kategori, brand))

        # 3. Proses Sapu Bersih (Delete produk yang sudah dihapus di panel Digiflazz)
        if sku_aktif_di_digi:
            format_strings = ','.join(['%s'] * len(sku_aktif_di_digi))
            cursor.execute(f"""
                DELETE FROM tabel_produk 
                WHERE sku NOT IN ({format_strings});
            """, tuple(sku_aktif_di_digi))
        else:
            # Jika respon kosong sama sekali, hapus semua produk demi keamanan sinkronisasi
            cursor.execute("DELETE FROM tabel_produk;")

        conn.commit()
        print(f"Sinkronisasi Berhasil! {len(sku_aktif_di_digi)} produk tersinkronisasi sempurna.")
        cursor.close()
        conn.close()
        return True

    except Exception as e:
        if conn:
            conn.rollback()
            conn.close()
        print(f"Error Anti-Bug Handler (Rollback sukses): {e}")
        return False
