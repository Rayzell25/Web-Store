import json
import os
from pyrogram import Client, filters
from pyrogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from config import *
from database import init_db, sinkronisasi_produk_digiflazz

# Inisialisasi Client Pyrogram
app = Client("cho_store_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# Load Database Zona (100% Seluruh Kota/Kabupaten Indonesia)
ZONA_FILE = "zona_data.json"
if os.path.exists(ZONA_FILE):
    with open(ZONA_FILE, "r", encoding="utf-8") as f:
        DB_ZONA = json.load(f)
else:
    DB_ZONA = {}
    print("Peringatan: File zona_data.json tidak ditemukan!")

# Daftar Prefix Resmi XL & Axis
PREFIX_XL_AXIS = [
    "0817", "0818", "0819", "0859", "0877", "0878", # Prefix XL
    "0831", "0832", "0833", "0838"                  # Prefix Axis
]

# State Memory untuk multi-step wizard (Anti-Tabrakan antar user)
user_steps = {}

# --- MENU UTAMA & START ---
@app.on_message(filters.command("start") | filters.regex("(?i)^menu utama$") | filters.regex("(?i)^kembali$"))
async def main_menu(client, message: Message):
    chat_id = message.chat.id
    if chat_id in user_steps:
        del user_steps[chat_id] # Reset state jika kembali ke menu utama
        
    keyboard = ReplyKeyboardMarkup(
        [
            [KeyboardButton("🛒 Beli Paket"), KeyboardButton("💳 Top Up Saldo")],
            [KeyboardButton("📝 Riwayat"), KeyboardButton("🔍 Cek Harga")],
            [KeyboardButton("🛠 Tools"), KeyboardButton("💬 Bantuan")]
        ],
        resize_keyboard=True
    )
    await message.reply_text("👋 Selamat datang di **CHO STORE PPOB**.\nSilakan pilih menu di bawah ini:", reply_markup=keyboard)

# --- MENU TOOLS ---
@app.on_message(filters.regex("(?i)^tools$"))
async def tools_menu(client, message: Message):
    keyboard = ReplyKeyboardMarkup(
        [
            [KeyboardButton("CEK PULSA"), KeyboardButton("CEK AREA")],
            [KeyboardButton("Menu Utama")]
        ],
        resize_keyboard=True
    )
    await message.reply_text("🛠 **TOOLS MENU**\n\nSilakan pilih alat bantu transaksi Anda:", reply_markup=keyboard)

# --- TOMBOL CEK PULSA ---
@app.on_message(filters.regex("(?i)^cek pulsa$"))
async def cek_pulsa_info(client, message: Message):
    await message.reply_text(
        "ℹ️ **INFORMASI UTAMA:**\n\n"
        "Untuk melakukan pengecekan **Sisa Paket, Kuota Aktif, dan Masa Aktif Jaringan** nomor secara detail seperti bot milik teman Anda, "
        "Sistem membutuhkan integrasi **API Cek Kuota khusus (Bukan API Digiflazz)**.\n\n"
        "Silakan hubungi Developer dan lampirkan `API URL` beserta `API Key` dari provider cek kuota Anda untuk mengaktifkan fitur pencarian ini secara live 100%!"
    )

# --- START WIZARD CEK AREA ---
@app.on_message(filters.regex("(?i)^cek area$"))
async def start_cek_area(client, message: Message):
    chat_id = message.chat.id
    user_steps[chat_id] = "menunggu_nomor"
    
    keyboard = ReplyKeyboardMarkup([[KeyboardButton("Batal")]], resize_keyboard=True)
    await message.reply_text(
        "📱 **FITUR CEK AREA XL/AXIS**\n─────────────────\n"
        "Silakan masukkan nomor HP target yang ingin diperiksa:\n"
        "*(Contoh: 087826532525)*", 
        reply_markup=keyboard
    )

# --- HANDLER PROSES INPUT USER (STATE MANAGEMENT) ---
@app.on_message(filters.text & filters.private)
async def handle_text_inputs(client, message: Message):
    chat_id = message.chat.id
    teks_raw = message.text
    teks_bersih = teks_raw.lower().strip()

    # Fitur Global Batal
    if teks_bersih == "batal":
        if chat_id in user_steps:
            del user_steps[chat_id]
        keyboard = ReplyKeyboardMarkup([[KeyboardButton("CEK AREA"), KeyboardButton("CEK PULSA")], [KeyboardButton("Menu Utama")]], resize_keyboard=True)
        await message.reply_text("✅ Proses pengecekan area dibatalkan.", reply_markup=keyboard)
        return

    # Cek apakah user sedang terdaftar di alur Cek Area
    if chat_id in user_steps:
        current_state = user_steps[chat_id]

        # TAHAP 1: VALIDASI NOMOR HP (KHUSUS XL / AXIS)
        if current_state == "menunggu_nomor":
            # Normalisasi nomor: mengubah +62 atau 62 menjadi 0
            nomor_normal = teks_bersih
            if nomor_normal.startswith("+62"):
                nomor_normal = "0" + nomor_normal[3:]
            elif nomor_normal.startswith("62"):
                nomor_normal = "0" + nomor_normal[2:]

            if not nomor_normal.isdigit() or not nomor_normal.startswith("08"):
                await message.reply_text("❌ **Format Salah!**\nMohon masukkan nomor HP yang valid berupa angka (Contoh: 087826532525):")
                return

            # Ambil 4 angka pertama (Prefix)
            prefix = nomor_normal[:4]
            if prefix not in PREFIX_XL_AXIS:
                await message.reply_text(
                    "❌ **NOMOR HP DITOLAK!**\n─────────────────\n"
                    "Nomor yang Anda masukkan bukan provider **XL atau AXIS**.\n\n"
                    "Fitur cek zona akrab ini hanya berjalan untuk nomor XL/Axis. Silakan masukkan nomor XL/Axis Anda:"
                )
                return

            # Nomor lolos validasi, naikkan ke Tahap 2
            user_steps[chat_id] = "menunggu_kota"
            await message.reply_text(
                "✅ **Nomor Terverifikasi XL/AXIS!**\n─────────────────\n"
                "Sekarang, silakan ketik nama **Kota atau Kabupaten** asal kartu Anda untuk melihat pembagian zonanya:\n\n"
                "*(Contoh: pati, bandung, surabaya, jepara, medan)*"
            )
            return

        # TAHAP 2: VALIDASI KOTA DAN OUTPUT AKHIR
        elif current_state == "menunggu_kota":
            # PEMBERSIHAN INPUT TOTAL (Anti-Bug & Typo)
            # Menghapus embel-embel administratif agar pencarian database akurat
            kota_target = teks_bersih
            kota_target = kota_target.replace("kab.", "").replace("kabupaten", "").replace("kota", "")
            kota_target = kota_target.strip() # hapus spasi sisa di ujung

            # Pencarian ke database JSON 100% Indonesia
            if kota_target in DB_ZONA:
                hasil_zona = DB_ZONA[kota_target]
                
                # Desain interface balasan rapi menyerupai bot teman user
                teks_balasan = (
                    f"   【 **HASIL CEK AREA** 】 ❞\n"
                    f"───────────────────────\n"
                    f"**Pencarian :** {teks_raw.title()}\n\n"
                    f"📦 **Kab/Kota {kota_target.title()}** ❞\n"
                    f"↳  `{hasil_zona}`\n"
                    f"───────────────────────"
                )
                
                keyboard = ReplyKeyboardMarkup([[KeyboardButton("CEK AREA"), KeyboardButton("CEK PULSA")], [KeyboardButton("Menu Utama")]], resize_keyboard=True)
                await message.reply_text(teks_balasan, reply_markup=keyboard)
                del user_steps[chat_id] # Hapus memori step karena proses sukses selesai
            else:
                # Anti-Crash Handler jika data ejaan salah atau kota belum terdaftar
                await message.reply_text(
                    "❌ **Area Tidak Ditemukan!**\n─────────────────\n"
                    "Nama kota/kabupaten tidak dikenali oleh sistem.\n\n"
                    "Silakan ketik nama kota lain dengan ejaan resmi tanpa disingkat (Contoh: `pati`, `sidoarjo`, `jakarta selatan`), atau ketik **Batal** untuk keluar."
                )
            return

# --- COMMAND TRIGER UPDATE MANUAL SINKRONISASI DIGIFLAZZ (Khusus Admin) ---
@app.on_message(filters.command("sync"))
async def trigger_sync(client, message: Message):
    await message.reply_text("🔄 Memulai sinkronisasi produk instan dari panel Digiflazz...")
    sukses = sinkronisasi_produk_digiflazz()
    if sukses:
        await message.reply_text("✅ **Sinkronisasi Berhasil Sempurna!**\nDatabase bot kini 100% sama dengan produk panel Digiflazz (Produk dihapus di panel otomatis hilang di bot).")
    else:
        await message.reply_text("❌ **Sinkronisasi Gagal!**\nPeriksa log VPS atau setingan config API Key Anda.")

if __name__ == "__main__":
    print("Menyiapkan struktur database VPS...")
    try:
        init_db()
    except Exception as e:
        print(f"Gagal koneksi database saat startup: {e}. Pastikan PostgreSQL VPS Anda menyala.")
        
    print("CHO STORE PPOB Bot berjalan aman...")
    app.run()
