# Configuration file for CHO STORE PPOB Bot
import os

API_ID = 1234567         # Ganti dengan API ID Telegram Anda
API_HASH = "abcdef123"   # Ganti dengan API HASH Telegram Anda
BOT_TOKEN = "12345:XYZ" # Ganti dengan Token Bot Telegram Anda

# Database Configuration (PostgreSQL VPS)
DB_HOST = "localhost"
DB_NAME = "db_bot"
DB_USER = "postgres"
DB_PASSWORD = "password_vps_anda"
DB_PORT = 5432

# Digiflazz Credentials
DIGIFLAZZ_USERNAME = "username_digi"
DIGIFLAZZ_API_KEY = "api_key_dev_atau_prod"
